# PvP Visuals (Fabric 1.21.4) — только визуал

Меню: **Right Shift** (переназначается в Управлении).

- HUD: ватермарка (FPS/ping/CPS), keystrokes + CPS, броня/предметы с прочностью, эффекты, Target HUD с плавной полоской HP, Combo, Hit marker
- HitColor: свой цвет подсветки при ударе (пресеты + Rainbow), слайдер интенсивности
- Hand position: X / Y / Z / размер рук-предметов (viewmodel)
- Конфиг: config/pvpvisuals.json

## Сборка
Java 21 + Gradle 8.12:
    gradle wrapper
    ./gradlew build        # jar -> build/libs/pvp-visuals-1.0.0.jar
Нужны Fabric Loader 0.16+ и Fabric API 0.119.2+1.21.4.

## Сборка без установки (GitHub)
1. Создайте репозиторий на github.com и загрузите в него содержимое этой папки.
2. Вкладка Actions -> Build mod jar -> дождитесь зелёной галочки.
3. Скачайте артефакт pvp-visuals-jar, достаньте jar (без -sources) и положите в .minecraft/mods.

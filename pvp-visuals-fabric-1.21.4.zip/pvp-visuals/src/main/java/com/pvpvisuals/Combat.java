package com.pvpvisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/** Tracks the last target, combo counter and hit marker. Visual info only. */
public final class Combat {
    public static LivingEntity target;
    public static long targetTime;
    public static float shownHealth;

    public static int combo;
    public static long comboTime;

    public static long hitMarkerUntil;

    private static int prevHurt;

    private Combat() {}

    public static void onAttack(Entity e) {
        long now = System.currentTimeMillis();
        if (e instanceof LivingEntity le) {
            if (target != le) shownHealth = le.getHealth();
            target = le;
            targetTime = now;

            if (now - comboTime < 3000) combo++;
            else combo = 1;
            comboTime = now;

            hitMarkerUntil = now + 300;
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            target = null;
            combo = 0;
            prevHurt = 0;
            return;
        }
        int ht = mc.player.hurtTime;
        if (ht > prevHurt) combo = 0; // we got hit -> combo broken
        prevHurt = ht;
    }
}

package com.pvpvisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class PvpScreen extends Screen {

    private static final int W = 150;
    private static final int ROW = 24;

    public PvpScreen() {
        super(Text.literal("PvP Visuals"));
    }

    @Override
    protected void init() {
        Config c = Config.I;
        int lx = width / 2 - W - 5;
        int rx = width / 2 + 5;
        int y0 = 44;

        // ---------------- left column: HUD
        int y = y0;
        toggle(lx, y, "HUD", () -> c.hud, v -> c.hud = v); y += ROW;
        toggle(lx, y, "Watermark", () -> c.watermark, v -> c.watermark = v); y += ROW;
        toggle(lx, y, "Keystrokes + CPS", () -> c.keystrokes, v -> c.keystrokes = v); y += ROW;
        toggle(lx, y, "Armor / items", () -> c.armor, v -> c.armor = v); y += ROW;
        toggle(lx, y, "Effects", () -> c.effects, v -> c.effects = v); y += ROW;
        toggle(lx, y, "Target HUD", () -> c.targetHud, v -> c.targetHud = v); y += ROW;
        toggle(lx, y, "Combo", () -> c.combo, v -> c.combo = v); y += ROW;
        toggle(lx, y, "Hit marker", () -> c.hitMarker, v -> c.hitMarker = v); y += ROW;
        cycle(lx, y, "Accent", () -> c.accentIdx, v -> c.accentIdx = v);

        // ---------------- right column: HitColor + viewmodel
        y = y0;
        toggle(rx, y, "HitColor", () -> c.hitColor, v -> c.hitColor = v); y += ROW;
        cycle(rx, y, "Hit color", () -> c.hitColorIdx, v -> c.hitColorIdx = v); y += ROW;
        addDrawableChild(new Slider(rx, y, W, "Hit intensity", 0f, 1f, c.hitIntensity, v -> c.hitIntensity = v)); y += ROW;
        toggle(rx, y, "Hand position", () -> c.viewmodel, v -> c.viewmodel = v); y += ROW;
        addDrawableChild(new Slider(rx, y, W, "Hand X", -0.5f, 0.5f, c.vmX, v -> c.vmX = v)); y += ROW;
        addDrawableChild(new Slider(rx, y, W, "Hand Y", -0.5f, 0.5f, c.vmY, v -> c.vmY = v)); y += ROW;
        addDrawableChild(new Slider(rx, y, W, "Hand Z", -0.5f, 0.5f, c.vmZ, v -> c.vmZ = v)); y += ROW;
        addDrawableChild(new Slider(rx, y, W, "Hand size", 0.3f, 1.5f, c.vmScale, v -> c.vmScale = v)); y += ROW;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset hand"), b -> {
            c.resetViewmodel();
            clearAndInit();
        }).dimensions(rx, y, W, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 - 100, height - 28, 200, 20).build());
    }

    private void toggle(int x, int y, String name, Supplier<Boolean> get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.get()), b -> {
            set.accept(!get.get());
            b.setMessage(label(name, get.get()));
        }).dimensions(x, y, W, 20).build());
    }

    private void cycle(int x, int y, String name, IntSupplier get, IntConsumer set) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + paletteName(get.getAsInt())), b -> {
            int next = (get.getAsInt() + 1) % Config.PALETTE.length;
            set.accept(next);
            b.setMessage(Text.literal(name + ": " + paletteName(next)));
        }).dimensions(x, y, W, 20).build());
    }

    private static String paletteName(int i) {
        return Config.PALETTE_NAMES[Math.floorMod(i, Config.PALETTE_NAMES.length)];
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int accent = 0xFF000000 | Config.rgb(Config.I.accentIdx);
        ctx.drawCenteredTextWithShadow(textRenderer, "PvP Visuals", width / 2, 10, accent);
        ctx.drawCenteredTextWithShadow(textRenderer, "HUD", width / 2 - W / 2 - 5, 30, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "HitColor / Hands", width / 2 + W / 2 + 5, 30, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private static class Slider extends SliderWidget {
        private final String name;
        private final float min, max;
        private final Consumer<Float> set;

        Slider(int x, int y, int w, String name, float min, float max, float cur, Consumer<Float> set) {
            super(x, y, w, 20, Text.empty(), (cur - min) / (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.set = set;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (name == null) return;
            setMessage(Text.literal(name + ": " + String.format("%.2f", min + (max - min) * value)));
        }

        @Override
        protected void applyValue() {
            set.accept((float) (min + (max - min) * value));
        }
    }
}

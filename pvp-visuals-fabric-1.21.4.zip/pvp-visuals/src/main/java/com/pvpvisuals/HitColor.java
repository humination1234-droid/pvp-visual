package com.pvpvisuals;

import com.pvpvisuals.mixin.OverlayTextureAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.render.OverlayTexture;

/**
 * Rewrites the "hurt" rows of the vanilla overlay texture so entities flash
 * in a custom color when damaged.
 * NOTE: the overlay shader does mix(overlay.rgb, color.rgb, overlay.a), so
 * alpha = how much of the original color is kept. intensity = 1 - alpha.
 */
public final class HitColor {
    private static final int VANILLA = 0xB2FF0000;
    private static int lastApplied = 0;
    private static boolean wasOn = false;
    private static int tickCounter = 0;

    private HitColor() {}

    public static void tick(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        Config c = Config.I;

        int argb;
        if (c.hitColor) {
            tickCounter++;
            if (Config.isRainbow(c.hitColorIdx) && tickCounter % 2 != 0) return;
            int alpha = Math.round(255f * (1f - Math.max(0f, Math.min(1f, c.hitIntensity))));
            argb = (alpha << 24) | Config.rgb(c.hitColorIdx);
        } else {
            argb = VANILLA;
        }

        if (argb == lastApplied && c.hitColor == wasOn) return;

        try {
            OverlayTexture ot = mc.gameRenderer.getOverlayTexture();
            NativeImageBackedTexture tex = ((OverlayTextureAccessor) (Object) ot).pv$getTexture();
            NativeImage img = tex.getImage();
            if (img == null) return;
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 16; x++) {
                    img.setColorArgb(x, y, argb);
                }
            }
            tex.upload();
            lastApplied = argb;
            wasOn = c.hitColor;
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}

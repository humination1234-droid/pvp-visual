package com.pvpvisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    // HUD
    public boolean hud = true;
    public boolean watermark = true;
    public boolean keystrokes = true;
    public boolean armor = true;
    public boolean effects = true;
    public boolean targetHud = true;
    public boolean combo = true;
    public boolean hitMarker = true;
    public int accentIdx = 0;

    // HitColor
    public boolean hitColor = true;
    public int hitColorIdx = 1;
    public float hitIntensity = 0.35f; // 0 = invisible, 1 = solid color

    // Viewmodel (hand position)
    public boolean viewmodel = true;
    public float vmX = 0.0f;
    public float vmY = -0.08f;
    public float vmZ = 0.0f;
    public float vmScale = 0.9f;

    public static final String[] PALETTE_NAMES = {"Cyan", "Purple", "Pink", "Green", "Orange", "Red", "White", "Rainbow"};
    public static final int[] PALETTE = {0x3CDCFF, 0xA855F7, 0xFF4FA3, 0x4ADE80, 0xFF9F43, 0xFF4D4D, 0xFFFFFF, -1};

    public static boolean isRainbow(int idx) {
        return PALETTE[Math.floorMod(idx, PALETTE.length)] == -1;
    }

    /** RGB (no alpha) of a palette entry. Rainbow animates over time. */
    public static int rgb(int idx) {
        int c = PALETTE[Math.floorMod(idx, PALETTE.length)];
        if (c == -1) {
            return MathHelper.hsvToRgb((System.currentTimeMillis() % 6000L) / 6000f, 0.65f, 1f) & 0xFFFFFF;
        }
        return c;
    }

    public void resetViewmodel() {
        viewmodel = true;
        vmX = 0.0f;
        vmY = -0.08f;
        vmZ = 0.0f;
        vmScale = 0.9f;
    }

    // ---------- persistence ----------
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpvisuals.json");
    }

    public static Config I = load();

    public static Config load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) return c;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Config();
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(I, w);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package com.pvpvisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Collection;

public final class Hud {

    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lDown, rDown;

    private static final int BG = 0xB0101018;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFBBBBCC;

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        pollClicks(mc);

        Config c = Config.I;
        if (!c.hud) return;

        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int accentRgb = Config.rgb(c.accentIdx);
        int accent = 0xFF000000 | accentRgb;

        if (c.watermark) drawWatermark(ctx, tr, mc, accent);
        if (c.effects) drawEffects(ctx, tr, mc, 6, c.watermark ? 28 : 6);
        if (c.armor) drawArmor(ctx, tr, mc, w, h, accent);
        if (c.keystrokes) drawKeystrokes(ctx, tr, mc, w - 6 - 64, h - 96, accentRgb);
        if (c.targetHud) drawTarget(ctx, tr, w, h, accent);
        if (c.combo) drawCombo(ctx, tr, w, h, accent);
        if (c.hitMarker) drawHitMarker(ctx, w, h, accentRgb);
    }

    // ------------------------------------------------------------ helpers

    private static void pollClicks(MinecraftClient mc) {
        long win = mc.getWindow().getHandle();
        long now = System.currentTimeMillis();
        boolean l = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !lDown) LEFT.addLast(now);
        if (r && !rDown) RIGHT.addLast(now);
        lDown = l;
        rDown = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.pollFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.pollFirst();
    }

    /** Rounded rectangle (radius r) built from filled rows. */
    private static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int d = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + d, y + i, x + w - d, y + i + 1, col);
            c.fill(x + d, y + h - i - 1, x + w - d, y + h - i, col);
        }
        c.fill(x, y + r, x + w, y + h - r, col);
    }

    private static void accentLine(DrawContext c, int x, int y, int w, int accent) {
        c.fill(x, y, x + w, y + 1, accent);
        c.fill(x, y + 1, x + w, y + 2, (0x44 << 24) | (accent & 0xFFFFFF));
    }

    private static int withAlpha(int rgb, int a) {
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int healthColor(float ratio) {
        ratio = MathHelper.clamp(ratio, 0f, 1f);
        return 0xFF000000 | (MathHelper.hsvToRgb(ratio * 0.33f, 0.75f, 1f) & 0xFFFFFF);
    }

    // ------------------------------------------------------------ watermark

    private static void drawWatermark(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int accent) {
        int ping = 0;
        ClientPlayNetworkHandler nh = mc.getNetworkHandler();
        if (nh != null) {
            PlayerListEntry e = nh.getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String title = "PvP Visuals";
        String info = "   " + mc.getCurrentFps() + " FPS   " + ping + " ms   " + LEFT.size() + " CPS";
        int tw = tr.getWidth(title);
        int iw = tr.getWidth(info);
        int x = 6, y = 6, w = tw + iw + 14, h = 16;
        rrect(ctx, x, y, w, h, 4, BG);
        accentLine(ctx, x + 4, y, w - 8, accent);
        ctx.drawTextWithShadow(tr, title, x + 7, y + 4, accent);
        ctx.drawTextWithShadow(tr, info, x + 7 + tw, y + 4, TEXT_DIM);
    }

    // ------------------------------------------------------------ effects

    private static void drawEffects(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int x, int y) {
        Collection<StatusEffectInstance> list = mc.player.getStatusEffects();
        if (list.isEmpty()) return;

        int maxW = 0;
        String[] lines = new String[list.size()];
        int[] colors = new int[list.size()];
        int i = 0;
        for (StatusEffectInstance e : list) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            String time;
            if (e.isInfinite()) {
                time = "--:--";
            } else {
                int sec = e.getDuration() / 20;
                time = (sec / 60) + ":" + String.format("%02d", sec % 60);
            }
            lines[i] = name + "  " + time;
            colors[i] = 0xFF000000 | (e.getEffectType().value().getColor() & 0xFFFFFF);
            maxW = Math.max(maxW, tr.getWidth(lines[i]));
            i++;
        }
        int w = maxW + 16;
        int h = lines.length * 12 + 6;
        rrect(ctx, x, y, w, h, 4, BG);
        for (int k = 0; k < lines.length; k++) {
            int ly = y + 4 + k * 12;
            ctx.fill(x + 3, ly, x + 5, ly + 9, colors[k]);
            ctx.drawTextWithShadow(tr, lines[k], x + 9, ly + 1, TEXT);
        }
    }

    // ------------------------------------------------------------ armor

    private static void drawArmor(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int w, int h, int accent) {
        EquipmentSlot[] slots = {
                EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.OFFHAND
        };
        ItemStack[] stacks = new ItemStack[slots.length];
        int rows = 0;
        for (int i = 0; i < slots.length; i++) {
            stacks[i] = mc.player.getEquippedStack(slots[i]);
            if (!stacks[i].isEmpty()) rows++;
        }
        if (rows == 0) return;

        int pw = 56;
        int ph = rows * 18 + 6;
        int x = w - 6 - pw;
        int y = h / 2 - ph / 2;
        rrect(ctx, x, y, pw, ph, 4, BG);
        accentLine(ctx, x + 4, y, pw - 8, accent);

        int row = 0;
        for (ItemStack s : stacks) {
            if (s.isEmpty()) continue;
            int iy = y + 4 + row * 18;
            ctx.drawItem(s, x + 3, iy);
            String label;
            int col = TEXT;
            if (s.isDamageable()) {
                int max = s.getMaxDamage();
                int pct = Math.round((max - s.getDamage()) * 100f / max);
                label = pct + "%";
                col = healthColor(pct / 100f);
            } else {
                label = s.getCount() > 1 ? "x" + s.getCount() : "";
            }
            ctx.drawTextWithShadow(tr, label, x + 23, iy + 5, col);
            row++;
        }
    }

    // ------------------------------------------------------------ keystrokes

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label,
                            boolean down, int accentRgb) {
        int bg = down ? withAlpha(accentRgb, 0xC0) : 0x90101018;
        rrect(ctx, x, y, w, h, 3, bg);
        int tw = tr.getWidth(label);
        ctx.drawTextWithShadow(tr, label, x + (w - tw) / 2, y + (h - 8) / 2 + 1, down ? 0xFF0B0B10 : TEXT);
    }

    private static void drawKeystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int x, int y, int accentRgb) {
        var o = mc.options;
        key(ctx, tr, x + 22, y, 20, 20, "W", o.forwardKey.isPressed(), accentRgb);
        key(ctx, tr, x, y + 22, 20, 20, "A", o.leftKey.isPressed(), accentRgb);
        key(ctx, tr, x + 22, y + 22, 20, 20, "S", o.backKey.isPressed(), accentRgb);
        key(ctx, tr, x + 44, y + 22, 20, 20, "D", o.rightKey.isPressed(), accentRgb);

        drawMouse(ctx, tr, x, y + 44, 31, "LMB", LEFT.size(), lDown, accentRgb);
        drawMouse(ctx, tr, x + 33, y + 44, 31, "RMB", RIGHT.size(), rDown, accentRgb);

        boolean jump = o.jumpKey.isPressed();
        rrect(ctx, x, y + 68, 64, 10, 3, jump ? withAlpha(accentRgb, 0xC0) : 0x90101018);
        ctx.fill(x + 20, y + 72, x + 44, y + 73, jump ? 0xFF0B0B10 : 0xFFDDDDDD);
    }

    private static void drawMouse(DrawContext ctx, TextRenderer tr, int x, int y, int w, String label, int cps,
                                  boolean down, int accentRgb) {
        rrect(ctx, x, y, w, 22, 3, down ? withAlpha(accentRgb, 0xC0) : 0x90101018);
        int col = down ? 0xFF0B0B10 : TEXT;
        ctx.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, col);
        String s = cps + " cps";
        ctx.drawTextWithShadow(tr, s, x + (w - tr.getWidth(s)) / 2, y + 12, down ? 0xFF2A2A35 : TEXT_DIM);
    }

    // ------------------------------------------------------------ target HUD

    private static void drawTarget(DrawContext ctx, TextRenderer tr, int sw, int sh, int accent) {
        LivingEntity t = Combat.target;
        if (t == null) return;
        long now = System.currentTimeMillis();
        if (now - Combat.targetTime > 5000 || t.isRemoved() || !t.isAlive()) return;

        float hp = t.getHealth();
        float max = Math.max(1f, t.getMaxHealth());
        Combat.shownHealth += (hp - Combat.shownHealth) * 0.12f;

        int pw = 124, ph = 34;
        int x = sw / 2 + 30;
        int y = sh / 2 + 16;

        rrect(ctx, x, y, pw, ph, 5, BG);
        accentLine(ctx, x + 5, y, pw - 10, accent);

        ctx.drawTextWithShadow(tr, t.getName().getString(), x + 7, y + 6, TEXT);

        int bx = x + 7, by = y + 19, bw = pw - 14, bh = 6;
        ctx.fill(bx, by, bx + bw, by + bh, 0xFF22222C);
        int fill = Math.round(bw * MathHelper.clamp(Combat.shownHealth / max, 0f, 1f));
        ctx.fill(bx, by, bx + fill, by + bh, healthColor(Combat.shownHealth / max));
        // bright marker for the real value
        int real = Math.round(bw * MathHelper.clamp(hp / max, 0f, 1f));
        ctx.fill(bx + real - 1, by, bx + real, by + bh, 0x66FFFFFF);

        String txt = String.format("%.1f / %.0f", hp, max);
        ctx.drawTextWithShadow(tr, txt, x + pw - 7 - tr.getWidth(txt), y + 6, TEXT_DIM);
    }

    // ------------------------------------------------------------ combo + hitmarker

    private static void drawCombo(DrawContext ctx, TextRenderer tr, int sw, int sh, int accent) {
        long now = System.currentTimeMillis();
        if (Combat.combo < 2 || now - Combat.comboTime > 3000) return;
        String s = "COMBO  x" + Combat.combo;
        int tw = tr.getWidth(s);
        int w = tw + 14, h = 15;
        int x = sw / 2 - w / 2, y = sh / 2 - 44;
        rrect(ctx, x, y, w, h, 4, BG);
        accentLine(ctx, x + 4, y, w - 8, accent);
        ctx.drawTextWithShadow(tr, s, x + 7, y + 4, accent);
    }

    private static void drawHitMarker(DrawContext ctx, int sw, int sh, int accentRgb) {
        long left = Combat.hitMarkerUntil - System.currentTimeMillis();
        if (left <= 0) return;
        int a = Math.min(255, (int) (255 * (left / 300f)));
        if (a < 8) return;
        int col = withAlpha(accentRgb, a);
        int cx = sw / 2, cy = sh / 2;
        for (int i = 3; i < 8; i++) {
            ctx.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, col);
            ctx.fill(cx - i - 1, cy + i, cx - i, cy + i + 1, col);
            ctx.fill(cx + i, cy - i - 1, cx + i + 1, cy - i, col);
            ctx.fill(cx - i - 1, cy - i - 1, cx - i, cy - i, col);
        }
    }
}
